const CACHE='bigskills-v1';
const ASSETS=['./','./index.html','./skills.js','./privacy.html','./manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  e.respondWith(
    caches.match(e.request).then(hit=>hit||fetch(e.request).then(res=>{
      const copy=res.clone();
      caches.open(CACHE).then(c=>{try{c.put(e.request,copy)}catch(_){}});
      return res;
    }).catch(()=>caches.match('./index.html')))
  );
});